import "indexof";
import "trim";